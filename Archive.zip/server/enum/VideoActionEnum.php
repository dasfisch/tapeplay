<?php

class VideoActionEnum
{
	public static $SAVE = 1;
	public static $VIEW = 2;
}
