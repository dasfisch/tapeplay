<?php

class EmailEnum
{
	public static $SHARE = "share";
	public static $PLAYER_JOIN = "player-join";
	public static $NONPLAYER_JOIN = "nonplayer-join";
	public static $PAYMENT = "payment";
	public static $VIDEO_PUBLISH = "video-publish";
	public static $INVITE_STAFF = "invite";
	public static $RENEW = "renew";
	public static $RESET_PASSWORD = "reset-password";
}
