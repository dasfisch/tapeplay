<?php

class AccountTypeEnum
{
	public static $ADMIN = 0;
	public static $PLAYER = 1;
	public static $COACH = 2;
	public static $SCOUT = 3;
}
