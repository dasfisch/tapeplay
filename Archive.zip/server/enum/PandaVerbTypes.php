<?php

class PandaVerbTypes
{
	public static $GET = "GET";
	public static $POST = "POST";
	public static $PUT = "PUT";
	public static $DELETE = "DELETE";
}
