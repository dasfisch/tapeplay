<?php

class SchoolPositionEnum
{
	public static $HEAD_COACH = 1;
	public static $ASSISTANT_COACH = 2;
	public static $STAFF = 3;
}
