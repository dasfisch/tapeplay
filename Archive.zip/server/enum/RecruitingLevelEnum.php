<?php

class RecruitingLevelEnum
{
	public static $HIGH_SCHOOL = 1;
	public static $COLLEGE = 2;
	public static $PROFESSIONAL = 23;
}
