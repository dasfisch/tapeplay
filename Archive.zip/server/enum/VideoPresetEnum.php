<?php

class VideoPresetEnums
{
	public static $H264 = "h264";
	public static $H264HI = "h264.hi";
	public static $OGG = "ogg";
	public static $WEBM = "webm";
	public static $IOS_ADAPTIVE = "iphone_and_ipad";
}
