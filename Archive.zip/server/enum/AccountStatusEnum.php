<?php

class AccountStatusEnum
{
	public static $STEP1 = 0; //hasn't even started
	public static $STEP2 = 1; //completed basic registration
	public static $STEP3 = 2; //completed video upload
	public static $COMPLETE = 3; //completed stats; profile is complete
}
