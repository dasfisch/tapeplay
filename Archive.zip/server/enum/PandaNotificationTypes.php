<?php

class PandaNotificationTypes
{
	public static $VIDEO_CREATED = "video-created";
	public static $VIDEO_ENCODED = "video-encoded";
	public static $ENCODING_PROGRESS = "encoding-progress";
	public static $ENCODING_COMPLETE = "encoding-complete";
}
