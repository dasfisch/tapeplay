<?php

class CoachCollegiateLevelEnum
{
	public static $DI = 1;
	public static $DII = 2;
	public static $DIII = 3;
}
