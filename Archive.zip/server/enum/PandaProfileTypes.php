<?php

class PandaProfileTypes
{
	public static $H264= "h264";
	public static $OGG = "ogg";
	public static $WEBM = "webm";
}
