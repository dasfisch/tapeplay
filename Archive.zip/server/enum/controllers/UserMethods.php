<?php

class UserMethods
{
	public static $LOGIN = "login";
	public static $FORGOT = "forgot";
	public static $LOGOUT = "logout";
	public static $SIGNUP = "signup";
	public static $PERSONAL = "personal";
	public static $UPLOAD = "upload";
	public static $INFO = "info";
	public static $PAYMENT = "payment";
	public static $CONFIRM = "confirm";

}
