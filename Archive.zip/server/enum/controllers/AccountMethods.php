<?php

class AccountMethods
{
	public static $WELCOME = "welcome";
    public static $FORGOT_PASSWORD = 'forgot';
}
