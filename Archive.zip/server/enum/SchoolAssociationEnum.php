<?php

class SchoolAssociationEnum
{
	public static $NCAA = 0;
	public static $NAIA = 1;
	public static $NJCAA = 2;
	public static $OTHER = 3;
}
