<?php

namespace tapeplay\server\model;

/**
 * Stores all configurable values for the site.
 */
class AppSettingsInfo
{
    public static $DB_USER = "tp_user_12";
    public static $DB_PASS = "tapeplay!";
    public static $DB_HOST = "localhost";
    public static $DB_DB = "dev_tapeplay";
}
?>