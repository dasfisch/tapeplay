<?php

namespace tapeplay\server\model;

class Ad
{
	private $_id;
	private $_title;
	private $_startDate;
	private $_endDate;
	private $_active;
	private $_url;
	private $_targetLocation;
	private $_targetYear;
	private $_targetSport;
	private $_targetAccountType;
	private $_adFormat;
}
