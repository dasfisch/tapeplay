<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'home' => 'http://localhost:3500/',
    'baseUrl' => 'http://localhost:3500/',
    'pandaBase' => 'https://s3.amazonaws.com/tpvideosdev/',
    'pandaImageExt' => '_1.jpg',
    'facebookUrl' => 'http://facebook.com/tapeplay',
    'googlePlusUrl' => 'http://plus.google.com/tapeplay',
    'twitterUrl' => 'http://twitter.com/tapeplay',
    'linkedInUrl' => 'http://linkedin.com/tapeplay',
    'facebookTitle' => 'TapePlay on Facebook',
    'googlePlusTitle' => 'TapePlay on Google+',
    'twitterTitle' => 'TapePlay on Twitter',
    'linkedInTitle' => 'TapePlay on LinkedIn',
    'blogUrl' => 'http://www.tapeplay.com/blog/',
    'shopUrl' => 'http://www.printfection.com/tapeplay/',
  ),
); ?>