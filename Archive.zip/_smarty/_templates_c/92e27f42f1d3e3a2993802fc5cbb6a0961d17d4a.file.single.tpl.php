<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 15:50:47
         compiled from "_smarty/_templates/videos/single.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1851877713502af07e5e10d6-97311646%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92e27f42f1d3e3a2993802fc5cbb6a0961d17d4a' => 
    array (
      0 => '_smarty/_templates/videos/single.tpl',
      1 => 1347828645,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1851877713502af07e5e10d6-97311646',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_502af07e7d4807_24448615',
  'variables' => 
  array (
    'player' => 0,
    'video' => 0,
    'goBack' => 0,
    'videoDisplayInfo' => 0,
    'user' => 0,
    'hash' => 0,
    'userId' => 0,
    'stats' => 0,
    'i' => 0,
    'modder' => 0,
    'stat' => 0,
    'statCount' => 0,
    'videos' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_502af07e7d4807_24448615')) {function content_502af07e7d4807_24448615($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/private/etc/libraries/libs/plugins/modifier.date_format.php';
?><div class="single">
	<h1><?php echo $_smarty_tpl->tpl_vars['player']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getLastName();?>
</h1>
	<ul class="video-title-data">
		<li><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</li>
		<li><?php echo $_smarty_tpl->tpl_vars['video']->value->getRecordedMonthName();?>
, <?php echo $_smarty_tpl->tpl_vars['video']->value->getRecordedYear();?>
</li>
	</ul>
	<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/search/<?php if ($_smarty_tpl->tpl_vars['goBack']->value==1){?>?back=1<?php }?>" class="return">Back to search results</a>
	<div class="clear"></div>
	<div class="video-player">
		<video id="videoPlayer" width="890" height="455">
            <source src="<?php echo $_smarty_tpl->tpl_vars['videoDisplayInfo']->value->getMp4Source();?>
"
                    type="video/mp4"/>
            <source src="<?php echo $_smarty_tpl->tpl_vars['videoDisplayInfo']->value->getWebmSource();?>
"
                    type="video/webm"/>
        </video>
        <script type='text/javascript'>
            jwplayer('videoPlayer').setup({
                modes:[
                    { type:"html5" },
                    { type:"flash", src:"/media/playback/player.swf" },
                    { type:"download" }
                ],
                skin:"/media/playback/skins/normal/tapeplayer.zip",
                autostart:false,
                dock:false,
                "controlbar.position":"over",
				"controlbar.idlehide": true
            });
        </script>
	</div>
	<div class="video-data">
		<ul>
			<li class="views"><b><?php echo $_smarty_tpl->tpl_vars['video']->value->getViews();?>
</b> Views</li>
			<li class="saves"><b><?php echo $_smarty_tpl->tpl_vars['video']->value->getSaves();?>
</b> Saves</li>
			<li class="upload-date">Uploaded <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value->getUploadDate(),"%B %d, %Y %I:%M %p");?>
</li>
			<li class="report">
                <div class="infoOpen">
                    Report Video
                    <div class="infoBubble">
                        <div class="directionTopMiddle"></div>
                        <div class="topLeft"></div>
                        <div class="topRight"></div>
                        <div class="middle">
                            <p>
                                Should we review this video to determine if it's appropriate?<Br/>
                                <a id="report">Yes</a> or <a class="close">No</a>
                            </p>
                        </div>
                        <div class="bottomLeft"></div>
                        <div class="bottomRight"></div>
                    </div>
                </div>
            </li>
			<?php if (isset($_smarty_tpl->tpl_vars['user']->value)&&!empty($_smarty_tpl->tpl_vars['user']->value)){?>
                <li class="save"><a href="#">Save</a></li>
            <?php }?>
			<li class="share">
                <div class="infoOpen">
                    Share
                    <div class="infoBubble">
                        <div class="directionTopMiddle"></div>
                        <div class="topLeft"></div>
                        <div class="topRight"></div>
                        <div class="middle">
                            <p>
                                Embed video (copy &amp; paste link):
                                <br/>
                                <a>http://tapeplay.com/asd8f69j</a>
                            </p>
                            <p>Email this video: <a href="">click here</a></p>
                            <p>
                                <span class="postVideo">Post video:</span> <span class="smallShare fbBlackSmall"></span> <span class="smallShare myBlackSmall"></span> <span class="smallShare twBlackSmall"></span> <span class="smallShare inBlackSmall"></span>
                            </p>
                        </div>
                        <div class="bottomLeft"></div>
                        <div class="bottomRight"></div>
                    </div>
                </div>
            </li>
		</ul>
		<input type="hidden" id="hash" value="<?php echo $_smarty_tpl->tpl_vars['hash']->value;?>
"/>
		<input type="hidden" id="user-id" value="<?php echo $_smarty_tpl->tpl_vars['userId']->value;?>
"/>
		<input type="hidden" id="video-id" value="<?php echo $_smarty_tpl->tpl_vars['video']->value->getId();?>
"/>
		<div class="clear"></div>
	</div>
	
	<div class="video-content">
		<div class="content-left left">
			<div class="user-info">
				<h1>#<?php echo $_smarty_tpl->tpl_vars['player']->value->getNumber();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getLastName();?>
</h1>
				<span class="grade"><img src="/media/images/icon_high-school-athlete.png" /></span>
				<ul class="user-profile">
					<li><?php echo $_smarty_tpl->tpl_vars['player']->value->getPosition();?>
, <?php echo $_smarty_tpl->tpl_vars['player']->value->getFriendlyHeight();?>
, <?php echo $_smarty_tpl->tpl_vars['player']->value->getWeight();?>
 lbs</li>
					<li><?php echo $_smarty_tpl->tpl_vars['player']->value->getGradeLevel();?>
/<?php echo $_smarty_tpl->tpl_vars['player']->value->getAge();?>
</li>
					<li><?php echo $_smarty_tpl->tpl_vars['player']->value->getSchool()->getName();?>
</li>
					<li>Coach&rsquo;s Name</li>
				</ul>
				
				<?php if (isset($_smarty_tpl->tpl_vars['stats']->value)&&count($_smarty_tpl->tpl_vars['stats']->value)>0){?>
					<ul class="user-stats three-column">
						<?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable(0, null, 0);?>
						<?php  $_smarty_tpl->tpl_vars['stat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['stat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['stats']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['stat']->key => $_smarty_tpl->tpl_vars['stat']->value){
$_smarty_tpl->tpl_vars['stat']->_loop = true;
?>
							<?php if ($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==0||$_smarty_tpl->tpl_vars['i']->value==0){?>
							<li>
							<?php }?>
							<?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatName();?>
: <?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatValue();?>

							<?php if (($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==$_smarty_tpl->tpl_vars['modder']->value-1&&$_smarty_tpl->tpl_vars['i']->value>$_smarty_tpl->tpl_vars['modder']->value)||$_smarty_tpl->tpl_vars['i']->value==($_smarty_tpl->tpl_vars['statCount']->value-1)){?>
							</li>
							<?php }?>
							<?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable($_smarty_tpl->tpl_vars['i']->value+1, null, 0);?>
						<?php } ?>
					</ul>
				<?php }?>
			
				<div class="clear"></div>
			</div>
			<h2>More videos from <?php echo $_smarty_tpl->tpl_vars['player']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getLastName();?>
</h2>
			<ul class="more-videos">
			
				<?php if (isset($_smarty_tpl->tpl_vars['videos']->value)&&count($_smarty_tpl->tpl_vars['videos']->value)>0){?>
					<?php  $_smarty_tpl->tpl_vars['video'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['video']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['videos']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['video']->key => $_smarty_tpl->tpl_vars['video']->value){
$_smarty_tpl->tpl_vars['video']->_loop = true;
?>
						<?php if ($_smarty_tpl->tpl_vars['video']->value->getPrivacy()==true){?>
							<li class="locked">
								<a href="#" onclick="return false;"><img src="/media/images/background_lock.png" /></a>
								<div class="video-image">
									<img src="https://s3.amazonaws.com/tpvideosdev/ba5dc5411fa485fa43056f4f3e18d600_1.jpg"/>
								</div>
								<ul>
									<li class="video-title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</li>
									<li class="name"><?php echo $_smarty_tpl->tpl_vars['player']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getLastName();?>
</li>
									<li class="month-year"><?php echo $_smarty_tpl->tpl_vars['video']->value->getUploadDate();?>
</li>
								</ul>
								<div class="clear"></div>
							</li>
							<!-- BUBBLE STUFF
							<div class="infoBubble leftCentered">
								<div class="topLeft"></div>
								<div class="topRight"></div>
								<div class="middle">
									<p>
										<strong>We're sorry.</strong> Only account holders can view this video.
										<br/><br/>
										Want to view this video?
										<br/>
										<a>Join</a> or <a>log in</a>.
									</p>
								</div>
								<div class="directionTopLeft"></div>
								<div class="bottomRight"></div>
								<div class="direction"></div>
							</div> -->
						<?php }else{ ?>
							<li>
								<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/view/<?php echo $_smarty_tpl->tpl_vars['video']->value->getId();?>
/"></a>
								<div class="video-image">
									<img src="https://s3.amazonaws.com/tpvideosdev/ba5dc5411fa485fa43056f4f3e18d600_1.jpg"/>
								</div>
								<ul>
									<li class="video-title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</li>
									<li class="name"><?php echo $_smarty_tpl->tpl_vars['player']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['player']->value->getLastName();?>
</li>
									<li class="month-year"><?php echo $_smarty_tpl->tpl_vars['video']->value->getUploadDate();?>
</li>
								</ul>
								<div class="clear"></div>
							</li>
						<?php }?>
					<?php } ?>
				<?php }?>
		
			</ul>
		</div>
		<div class="content-right left">
			<div class="ad_300x250 right">
				<a href="http://www.tapeplay.com/blog/"><img src="/media/images/ad_tapeplay-blog_300x250.jpg" /></a>
			</div>
		</div>
	</div>
	
</div>
<div class="clear"></div>

					<!-- SAVE BUBBLE STUFF
					<a id="save">Save</a>

					<div class="infoBubble">
						<div class="directionTopMiddle"></div>
						<div class="topLeft"></div>
						<div class="topRight"></div>
						<div class="middle">
							<p><span class="bold">Success!</span> This video has been saved to your account.</p>
						</div>
						<div class="bottomLeft"></div>
						<div class="bottomRight"></div>
					</div>

					<a class="infoOpen">Save</a>

					<div class="infoBubble">
						<div class="directionTopMiddle"></div>
						<div class="topLeft"></div>
						<div class="topRight"></div>
						<div class="middle">
							<p>
								<span class="bold">We're sorry.</span> Only account holders can save videos.</p>
							</p>
							<p>Please <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/">join</a> or <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/">log
								in</a> now.</p>
						</div>
						<div class="bottomLeft"></div>
						<div class="bottomRight"></div>
					</div> -->

				<!-- REPORT BUBBLE STUFF
				<li class="link last">
					<a class="infoOpen">Report Video</a>

					<div class="infoBubble">
						<div class="directionTopMiddle"></div>
						<div class="topLeft"></div>
						<div class="topRight"></div>
						<div class="middle">
							<p>
								Should we review this video to determine if it's appropriate?<Br/>
								<a id="report">Yes</a> or <a class="close">No</a>
							</p>
						</div>
						<div class="bottomLeft"></div>
						<div class="bottomRight"></div>
					</div>
				</li> --><?php }} ?>