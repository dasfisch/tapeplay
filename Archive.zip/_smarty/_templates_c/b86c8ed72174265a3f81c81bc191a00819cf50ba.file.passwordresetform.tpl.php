<?php /* Smarty version Smarty-3.1.10, created on 2012-09-07 18:24:30
         compiled from "_smarty/_templates/account/passwordresetform.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20623486465036e93057eda4-40351619%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b86c8ed72174265a3f81c81bc191a00819cf50ba' => 
    array (
      0 => '_smarty/_templates/account/passwordresetform.tpl',
      1 => 1347060269,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20623486465036e93057eda4-40351619',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5036e93057fa42_68438713',
  'variables' => 
  array (
    'auth' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5036e93057fa42_68438713')) {function content_5036e93057fa42_68438713($_smarty_tpl) {?><h1>Reset Your Password</h1>
<?php echo $_smarty_tpl->getSubTemplate ('common/message.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form id="passwordReset" name="passwordReset" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
account/password/?auth=<?php echo $_smarty_tpl->tpl_vars['auth']->value;?>
&email=<?php echo $_smarty_tpl->tpl_vars['email']->value;?>
" method="post">
    <input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['auth']->value;?>
" name="auth" />
    <input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['email']->value;?>
" name="email" />
    <ul class="form-fields">
        <li class="input-field clear">

            <div class="input_custom-text input_text80 width600 left">
                <div class="custom-input_center custom-input_partial">
                    <span class="custom-input_top"></span>
                    <input type="text" class="input_password" name="password" value="Enter Password" />
                    <span class="custom-input_bottom"></span>
                </div>

                <div class="custom-input_left custom-input_partial">
                    <span class="custom-input_top"></span>
                    <span class="custom-input_bottom"></span>
                </div>

                <div class="custom-input_right custom-input_partial">
                    <span class="custom-input_top"></span>
                    <span class="custom-input_bottom"></span>
                </div>

            </div>
            <div class="error-alert">
                <ul>
                    <li>This email address is not registered.</li>
                    <li>Try another email address or <a href="#">join now</a>.</li>
                </ul>
            </div>

        </li>

        <li class="input-field clear">

            <div class="input_custom-text input_text80 width600 left">
                <div class="custom-input_center custom-input_partial">
                    <span class="custom-input_top"></span>
                    <input type="text" class="input_password" name="password" value="Confirm Password" />
                    <span class="custom-input_bottom"></span>
                </div>

                <div class="custom-input_left custom-input_partial">
                    <span class="custom-input_top"></span>
                    <span class="custom-input_bottom"></span>
                </div>

                <div class="custom-input_right custom-input_partial">
                    <span class="custom-input_top"></span>
                    <span class="custom-input_bottom"></span>
                </div>

            </div>
            <div class="error-alert">
                <ul>
                    <li>This email address is not registered.</li>
                    <li>Try another email address or <a href="#">join now</a>.</li>
                </ul>
            </div>

        </li>
		<li class="input-field clear">
			<button type="submit" value="Continue" class="button_black_large left button_round">Continue</button>
		</li>
	</ul>
</form>
<?php }} ?>