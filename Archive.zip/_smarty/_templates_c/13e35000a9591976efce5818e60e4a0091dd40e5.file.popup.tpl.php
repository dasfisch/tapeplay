<?php /* Smarty version Smarty-3.1.10, created on 2012-09-21 11:52:19
         compiled from "_smarty/_templates/popup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:741680215505c9b4379c721-63480309%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13e35000a9591976efce5818e60e4a0091dd40e5' => 
    array (
      0 => '_smarty/_templates/popup.tpl',
      1 => 1347632613,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '741680215505c9b4379c721-63480309',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '(\'file\')' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_505c9b438395a6_00989182',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_505c9b438395a6_00989182')) {function content_505c9b438395a6_00989182($_smarty_tpl) {?><!DOCTYPE HTML>
<html id="www-tapeplay-com">
<head>
	<title>TapePlay</title>
	<link rel="stylesheet" href="/css/reset.css" type="text/css"/>
	<link rel="stylesheet" href="/css/tapeplay.css" type="text/css"/>
	<link rel="stylesheet" href="/css/global.css" type="text/css"/>

	<!-- OLD HEADER STYLES/SCRIPTS

			<link rel="stylesheet" href="/css/jquery.css" type="text/css" />

			<script type="text/javascript" src="/js/jquery.js"></script>
			<script type="text/javascript" src="/js/jquery-ui.js"></script>
			<script type="text/javascript" src="/js/tapeplay.js"></script>
			<script type="text/javascript" src="/js/jquery.panda.min.js"></script>
			-->

</head>
<body class="popup">
<?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars[('file')]->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</body>
</html><?php }} ?>