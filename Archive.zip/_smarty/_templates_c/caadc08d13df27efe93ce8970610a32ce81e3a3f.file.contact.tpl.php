<?php /* Smarty version Smarty-3.1.10, created on 2012-09-21 12:17:37
         compiled from "_smarty/_templates/company/contact.tpl" */ ?>
<?php /*%%SmartyHeaderCode:42830912550344ce47a5857-18752884%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'caadc08d13df27efe93ce8970610a32ce81e3a3f' => 
    array (
      0 => '_smarty/_templates/company/contact.tpl',
      1 => 1347761633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '42830912550344ce47a5857-18752884',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_50344ce491b2c4_73896208',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50344ce491b2c4_73896208')) {function content_50344ce491b2c4_73896208($_smarty_tpl) {?><div id="content-left-column" class="left">
	<h1>Contact Us</h1>
	
	<div class="contact-us-squares left">
		<h2>General Inquiries</h2>
		<p>
			If you need help, please <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/faq/" title="Frequently Asked Questions (FAQ)">visit our FAQs</a>. There you'll find answers to many common questions about using TapePlay.
		</p>
		<p>
			Still can&rsquo;t find the answer? We&rsquo;re here to help. Drop us a line.
		</p>
		<p class="font24">
			<a href="mailto:help@tapeplay.com" title="Email TapePlay Help">help@tapeplay.com</a>
		</p>
	</div>
	
	<div class="contact-us-squares left">
		<h2>Legal Concerns</h2>
		<p>
			If you want to report site abuse or are the copyright owner of a video that has been uploaded without your permission, please contact us.
		</p>
		<p class="font24">
			<a href="mailto:legal@tapeplay.com" title="Email TapePlay Legal">legal@tapeplay.com</a>
		</p>
	</div>
	
	<div class="contact-us-squares left">
		<h2>Media Inquiries</h2>
		<p>
			Send your media and press inquiries our way.
		</p>
		<p class="font24">
			<a href="mailto:media@tapeplay.com" title="Email TapePlay Media">media@tapeplay.com</a>
		</p>
	</div>
	
	<div class="contact-us-squares left">
		<h2>Advertising</h2>
		<p>
			Interested in spreading your message through TapePlay? We&rsquo;d love to do business with you.
		</p>
		<p class="font24">
			<a href="mailto:advertising@tapeplay.com" title="Email TapePlay Advertising">advertising@tapeplay.com</a>
		</p>
	</div>
	
</div>

<div id="content-right-column" class="right">
	<?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>