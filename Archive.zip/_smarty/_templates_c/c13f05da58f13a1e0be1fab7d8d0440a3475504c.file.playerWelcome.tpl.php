<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 14:44:37
         compiled from "_smarty/_templates/account/welcome/playerWelcome.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14360191545013446f930f50-06367465%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c13f05da58f13a1e0be1fab7d8d0440a3475504c' => 
    array (
      0 => '_smarty/_templates/account/welcome/playerWelcome.tpl',
      1 => 1347824640,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14360191545013446f930f50-06367465',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5013446fa61f91_30965751',
  'variables' => 
  array (
    'user' => 0,
    'hash' => 0,
    'myVideoWording' => 0,
    'videoCount' => 0,
    'videos' => 0,
    'video' => 0,
    'birthYear' => 0,
    'gender' => 0,
    'zipcode' => 0,
    'school' => 0,
    'stats' => 0,
    'i' => 0,
    'modder' => 0,
    'stat' => 0,
    'statCount' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5013446fa61f91_30965751')) {function content_5013446fa61f91_30965751($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/private/etc/libraries/libs/plugins/modifier.date_format.php';
?><div id="content-left-column">
    <h1>Welcome, <?php echo $_smarty_tpl->tpl_vars['user']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value->getLastName();?>
</h1>
    <div class="box">
        <input type="hidden" id="hash" value="<?php echo $_smarty_tpl->tpl_vars['hash']->value;?>
" />
        <input type="hidden" id="user-id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getUserId();?>
" />
        <ul>
            <li>
                <a href="#" class="opener"><?php echo $_smarty_tpl->tpl_vars['myVideoWording']->value;?>
 (<?php echo $_smarty_tpl->tpl_vars['videoCount']->value;?>
)</a>
                <div class="slide">
                    <div class="holder scrollable-area">
                        <ul>
                            <?php if (isset($_smarty_tpl->tpl_vars['videos']->value)&&!empty($_smarty_tpl->tpl_vars['videos']->value)){?>
                                <?php  $_smarty_tpl->tpl_vars['video'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['video']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['videos']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['video']->key => $_smarty_tpl->tpl_vars['video']->value){
$_smarty_tpl->tpl_vars['video']->_loop = true;
?>
                                    <li>
                                    <?php if ($_smarty_tpl->tpl_vars['video']->value->getPrivacy()==true){?>
                                        <div class="result opaque">
                                            <div class="infoOpen">
                                                <img src="<?php echo $_smarty_tpl->getConfigVariable('pandaBase');?>
<?php echo $_smarty_tpl->tpl_vars['video']->value->getPandaId();?>
<?php echo $_smarty_tpl->getConfigVariable('pandaImageExt');?>
.jpg" class="resultImage locked" />
                                                <div class="info">
                                                    <h2><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getLastName();?>
</h2>
                                                    <p class="position"></p>
                                                    <p class="title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</p>
                                                    <p class="date"><<?php ?>?php echo date('F, Y', strtotime('now')); ?<?php ?>></p>
                                                </div>
                                            </div>
                                            <div class="infoBubble">
                                                <div class="topLeft"></div>
                                                <div class="topRight"></div>
                                                <div class="middle">
                                                    <p>
                                                        <strong>We're sorry.</strong> Only account holders can view this video.
                                                        <br /><br />
                                                        Want to view this video?
                                                        <br />
                                                        <a>Join</a> or <a>log in</a>.
                                                    </p>
                                                </div>
                                                <div class="directionBottomRight"></div>
                                                <div class="bottomRight"></div>
                                                <div class="direction"></div>
                                            </div>
                                            <div class="bigButton orange" id="removeVideo">
                                                <div class="topLeft whiteBg"></div>
                                                <div class="topRight whiteBg"></div>
                                                <div class="bottomLeft whiteBg"></div>
                                                <div class="bottomRight whiteBg"></div>
                                                <div class="middle">
                                                    <input type="submit" value="Remove" id="remove" name="remove" class="tiny orange" />
                                                </div>
                                            </div>
                                        </div>
                                    <?php }else{ ?>
                                        <div class="result">
                                            <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/view/<?php echo $_smarty_tpl->tpl_vars['video']->value->getId();?>
/">
                                                <img src="<?php echo $_smarty_tpl->getConfigVariable('pandaBase');?>
<?php echo $_smarty_tpl->tpl_vars['video']->value->getPandaId();?>
<?php echo $_smarty_tpl->getConfigVariable('pandaImageExt');?>
.jpg" class="resultImage" />
                                                <div class="info">
                                                    <h4><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getLastName();?>
</h4>
                                                    <p class="title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</p>
                                                    <p class="date"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value->getUploadDate(),"B%, %Y");?>
</p>
                                                </div>
                                            </a>
                                            <div class="bigButton orange" id="removeVideo">
                                                <div class="topLeft whiteBg"></div>
                                                <div class="topRight whiteBg"></div>
                                                <div class="bottomLeft whiteBg"></div>
                                                <div class="bottomRight whiteBg"></div>
                                                <div class="middle">
                                                    <input type="submit" value="Remove" id="remove" name="remove" class="tiny orange" />
                                                </div>
                                            </div>
                                            <input type="hidden" class="video-id" value="<?php echo $_smarty_tpl->tpl_vars['video']->value->getId();?>
" />
                                        </div>
                                    <?php }?>
                                    </li>
                                <?php } ?>
                            <?php }?>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <div class="accordion">
        <div class="header">
            <div class="title">Account</div>
            <div class="arrow down"></div>
        </div>
        <div class="body">
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Name</h4>
                    <div class="inputField bottom hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="text" class="standard" id="_firstName" name="first_name" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getFirstName();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="text" class="standard" id="_lastName" name="last_name" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getLastName();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p><?php echo $_smarty_tpl->tpl_vars['user']->value->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value->getLastName();?>
</p>
                </div>
                <div class="bigButton orange userEdit" id="name">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Email Address</h4>
                    <div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="text" class="standard" id="_email" name="email" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getEmail();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p><?php echo $_smarty_tpl->tpl_vars['user']->value->getEmail();?>
</p>
                </div>
                <div class="bigButton orange userEdit">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Password</h4>
                    <div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="password" class="standard" id="_hash" name="password" value="" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p>*********</p>
                </div>
                <div class="bigButton orange userEdit">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="deactivate">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Deactivate</h4>
                    <!--<div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="text" class="standard" id="birthYear" name="birthYear" value="<?php echo $_smarty_tpl->tpl_vars['birthYear']->value;?>
" />
                            <input type="text" class="standard" id="gender" name="gender" value="<?php echo $_smarty_tpl->tpl_vars['gender']->value;?>
" />
                            <input type="text" class="standard" id="zipcode" name="zipcode" value="<?php echo $_smarty_tpl->tpl_vars['zipcode']->value;?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p><?php echo $_smarty_tpl->tpl_vars['user']->value->getBirthYear();?>
 / <?php echo $_smarty_tpl->tpl_vars['user']->value->getGender();?>
 / <?php echo $_smarty_tpl->tpl_vars['user']->value->getZipcode();?>
</p>-->
                </div>
                <div class="bigButton orange" id="deactivate">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Deactivate</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion">
        <div class="header">
            <div class="title"><?php echo $_smarty_tpl->tpl_vars['user']->value->getSport()->getSportName();?>
</div>
            <div class="arrow down"></div>
        </div>
        <div class="body">
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Number / Level / Grade</h4>
                    <div class="inputField numLevGrad hidden">
                        <div class="left"></div>
                        <div class="middle small">
                            <input type="text" class="standard small" id="_number" name="number" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getNumber();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <!-- Playing Level is not something set by the user; Why? -->
                        <fieldset>
                            <select class="select-5" name="_playingLevel" id="_playingLevel">
                                <option class="default">Grade</option>
                                <option>Grade School</option>
                                <option>High School</option>
                                <option>College</option>
                                <option>Professional</option>
                            </select>
                        </fieldset>
                    <div class="inputField numLevGrad hidden">
                        <div class="left"></div>
                        <div class="middle small">
                            <input type="text" class="standard small" id="_gradeLevel" name="grade" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getGradeLevel();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p>#<?php echo $_smarty_tpl->tpl_vars['user']->value->getNumber();?>
 / <?php echo $_smarty_tpl->tpl_vars['user']->value->getPlayingLevel();?>
 / <?php echo $_smarty_tpl->tpl_vars['user']->value->getGradeLevel();?>
</p>
                </div>
                <div class="bigButton orange playerEdit" id="number-level">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Position / Height</h4>
                    <div class="inputField option hidden">
                        <div class="checkbox">
                            <div class="box">
                                <div class="checkMark"></div>
                            </div>
                            <div class="label">Point Guard</div>
                            <input type="checkbox" class="checkValue hidden" name="position" value="PG" />
                        </div>
                        <div class="checkbox">
                            <div class="box">
                                <div class="checkMark"></div>
                            </div>
                            <div class="label">Shooting Guard</div>
                            <input type="checkbox" class="checkValue hidden" name="position" value="SG" />
                        </div>
                        <div class="checkbox">
                            <div class="box">
                                <div class="checkMark"></div>
                            </div>
                            <div class="label">Small Forward</div>
                            <input type="checkbox" class="checkValue hidden" name="position" value="SF" />
                        </div>
                        <div class="checkbox">
                            <div class="box">
                                <div class="checkMark"></div>
                            </div>
                            <div class="label">Power Forward</div>
                            <input type="checkbox" class="checkValue hidden" name="position" value="PF" />
                        </div>
                        <div class="checkbox">
                            <div class="box">
                                <div class="checkMark"></div>
                            </div>
                            <div class="label">Center</div>
                            <input type="checkbox" class="checkValue hidden" name="position" value="C" />
                        </div>
                    </div>
                    <div class="inputField hidden">
                        <div class="height">
                            <div class="sportSelect">
                                <div class="dropper">
                                    <div class="leftMedium"></div>
                                    <div class="middleMedium middle">
                                        <p class="value">Height</p>
                                        <input type="hidden" name="height" class="dropVal" value="" />
                                    </div>
                                    <div class="rightMedium"></div>
                                    <ul class="potentials">
                                        <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=96) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = (int)48;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = ((int)1) == 0 ? 1 : (int)1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                                            <li>
                                                <?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>

                                                <input type="hidden" class="value" value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
" />
                                            </li>
                                        <?php endfor; endif; ?>
                                    </ul>
                                </div>
                                <div class="arrowSmall"></div>
                            </div>
                        </div>
                    </div>
                    <p><?php echo $_smarty_tpl->tpl_vars['user']->value->getPosition();?>
 / <?php echo $_smarty_tpl->tpl_vars['user']->value->getHeight();?>
</p>
                </div>
                <div class="bigButton orange playerEdit" id="height-position">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>School Name</h4>
                    <div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <?php $_smarty_tpl->tpl_vars['school'] = new Smarty_variable($_smarty_tpl->tpl_vars['user']->value->getSchool()->getName(), null, 0);?>
                            <input type="text" class="standard small" id="schoolSearchInput" name="schoolName"
                                   value="<?php if (isset($_smarty_tpl->tpl_vars['school']->value)&&$_smarty_tpl->tpl_vars['school']->value!=''){?><?php echo $_smarty_tpl->tpl_vars['school']->value;?>
<?php }else{ ?>Please select a school!<?php }?>" />
                            <input type="hidden" class="passer" value="" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p><?php if (isset($_smarty_tpl->tpl_vars['school']->value)&&$_smarty_tpl->tpl_vars['school']->value!=''){?><?php echo $_smarty_tpl->tpl_vars['school']->value;?>
<?php }else{ ?>Please select a school!<?php }?></p>
                </div>
                <div class="bigButton orange schoolEdit" id="school">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Head Coach's Name</h4>
                    <div class="inputField hidden">
                        <div class="left"></div>
                        <div class="middle">
                            <input type="text" class="standard small" id="_coachName" name="coachName" value="<?php echo $_smarty_tpl->tpl_vars['user']->value->getCoachName();?>
" />
                        </div>
                        <div class="right"></div>
                    </div>
                    <p><?php echo $_smarty_tpl->tpl_vars['user']->value->getCoachName();?>
</p>
                </div>
                <div class="bigButton orange playerEdit" id="coach">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
            <div class="chunk">
                <div class="accountInfo">
                    <h4>Statistics</h4>
                    <div id="statistics">
                        <ul id="stats">
                            <?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable(0, null, 0);?>
                            <?php  $_smarty_tpl->tpl_vars['stat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['stat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['stats']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['stat']->key => $_smarty_tpl->tpl_vars['stat']->value){
$_smarty_tpl->tpl_vars['stat']->_loop = true;
?>
                                <?php if ($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==0||$_smarty_tpl->tpl_vars['i']->value==0){?>
                                    <li>
                                <?php }?>
                                        <div class="stat">
                                            <p>
                                                <?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatName();?>
:
                                                <span class="bold"><?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatValue();?>
</span>
                                            </p>
                                        </div>
                                        <div class="statHidden hidden">
                                            <p>
                                                <?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatName();?>
:
                                            </p>
                                            <div class="inputFieldSmall">
                                                <div class="left"></div>
                                                <div class="middle">
                                                    <input type="text" class="standard small" id="stat" name="stat-<?php echo $_smarty_tpl->tpl_vars['stat']->value->getId();?>
" value="<?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatValue();?>
" />
                                                </div>
                                                <div class="right"></div>
                                            </div>
                                        </div>
                                <?php if (($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==$_smarty_tpl->tpl_vars['modder']->value-1&&$_smarty_tpl->tpl_vars['i']->value>$_smarty_tpl->tpl_vars['modder']->value)||$_smarty_tpl->tpl_vars['i']->value==($_smarty_tpl->tpl_vars['statCount']->value-1)){?>
                                    </li>
                                <?php }?>
                                <?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable($_smarty_tpl->tpl_vars['i']->value+1, null, 0);?>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <div class="bigButton orange" id="statButton">
                    <div class="topLeft whiteBg"></div>
                    <div class="topRight whiteBg"></div>
                    <div class="bottomLeft whiteBg"></div>
                    <div class="bottomRight whiteBg"></div>
                    <div class="middle tiny">
                        <span class="edit">Edit</span>
                    </div>
                </div>
                <div class="status hidden">
                    <div class="greenCheckMark"></div>
                    <!--<span>Success!</span>-->
                </div>
            </div>
        </div>
    </div>
    <div class="accordion">
        <div class="header">
            <div class="title">Privacy</div>
            <div class="arrow down"></div>
        </div>
        <div class="body">
            <div class="chunk">
                <p class="check">
                    Who can view my videos?<br />
                    <input type="radio" name="visibility" value="Anybody" /> <label>Anybody</label><br />
                    <input type="radio" name="visibility" value="Scouts and Coaches" /> <label>Scouts and Coaches</label><br />
                    <input type="radio" name="visibility" value="Nobody" /> <label>Nobody</label><br />
                </p>
                <br />
                <p class="check">
                    <input type="checkbox" name="allowFacebook" id="allowFacebook" />
                    <label for="allowFacebook">Allow TapePlay to import my Facebook info</label>
                </p>
                <p class="check">
                    <input type="checkbox" name="relevantAdvertising" id="relevantAdvertising" />
                    <label for="relevantAdvertising">
                        Use my account info for relevant advertising.
                        <a class="infoOpen">Why?</a>
                        <div class="infoBubble">
                            <div class="topLeft black"></div>
                            <div class="directionTopRight"></div>
                            <div class="middle">
                                <p>
                                    Help us out by using your account info for relevant
                                    advertising. Ads help us pay the bills so we can
                                    keep improving TapePlay for you.
                                </p>
                            </div>
                            <div class="bottomLeft"></div>
                            <div class="bottomRight"></div>
                            <div class="direction"></div>
                        </div>
                    </label>
                </p>
                <p class="check">
                    <input type="checkbox" name="sendRecommendations" id="sendRecommendations" />
                    <label for="sendRecommendations">Send me recommendations about how to use TapePlay</label>
                </p>
            </div>
        </div>
    </div>
</div>
<div id="content-right-column" class="right">
    <?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>