<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 16:41:59
         compiled from "_smarty/_templates/company/helpcenter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20396906055031b3cd1abdf2-15498241%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5fcb4981b021e6b79f4ba56af69d63ae99ddda85' => 
    array (
      0 => '_smarty/_templates/company/helpcenter.tpl',
      1 => 1347761633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20396906055031b3cd1abdf2-15498241',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5031b3cd1dd267_98715148',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5031b3cd1dd267_98715148')) {function content_5031b3cd1dd267_98715148($_smarty_tpl) {?><div id="content-left-column" class="left">
	<h1>Help Center</h1>

	<h2>Get Started</h2>

	<p>
		TapePlay was created for the player. We&rsquo;re here to give power back to the talented athletes that deserve to be seen by coaches and scouts, not just the well connected. <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/getstarted/" title="Get Started">Get started now</a>.
	</p>

	<h2>Frequently Asked Questions</h2>

	<p>
		If you need help, please <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/faq/" title="Frequently Asked Questions (FAQ)">visit our FAQs</a>. There you&rsquo;ll find answers to many common questions about using TapePlay.
	</p>

	<h2>Do&rsquo;s and Don&rsquo;ts</h2>

	<p>
		Find out the rules of video on TapePlay. <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/guidelines/" title="Do's and Dont's">Click here</a> to see what you can and can&rsquo;t do when uploading a video.
	</p>

	<h2>Advertising</h2>

	<p>
		Get access to one of the most highly engaged audiences around with TapePlay. <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/advertising/" title="Advertising">Learn more</a>.
	</p>
</div>

<div id="content-right-column" class="right">
	<?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>