<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 16:56:00
         compiled from "_smarty/_templates/videos/videoSearch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19233676725032c75db50438-94508166%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64b45e0755fe399c64f62cd007f15ec889d29db8' => 
    array (
      0 => '_smarty/_templates/videos/videoSearch.tpl',
      1 => 1347683527,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19233676725032c75db50438-94508166',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5032c75dbe16e5_09661474',
  'variables' => 
  array (
    'videoCount' => 0,
    'videos' => 0,
    'video' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5032c75dbe16e5_09661474')) {function content_5032c75dbe16e5_09661474($_smarty_tpl) {?><div class="search">
	<div id="content-left-column" class="left">
	
		<form name="search" method="post" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/search/">
			<ul class="form-fields">
				<li class="input-field clear">
					
					<div class="input_custom-text input_text80 width425 left">
						<div class="custom-input_center custom-input_partial">
							<span class="custom-input_top"></span>
							<input type="text" name="search" value=""/>
							<span class="custom-input_bottom"></span>
						</div>
						
						<div class="custom-input_left custom-input_partial">
							<span class="custom-input_top"></span>
							<span class="custom-input_bottom"></span>
						</div>
											
						<div class="custom-input_right custom-input_partial">
							<span class="custom-input_top"></span>
							<span class="custom-input_bottom"></span>
						</div>
						
					</div>
					
					<button href="#" class="button_black_medium left">Search</button>
				</li>
				<li>
					<?php if ($_smarty_tpl->tpl_vars['videoCount']->value>0){?>
				        <p class="results"><?php echo $_smarty_tpl->tpl_vars['videoCount']->value;?>
 results</p>
				    <?php }?>
				</li>
			</ul>
		</form>
		
		<?php if ($_smarty_tpl->tpl_vars['videoCount']->value>0){?>
			<ul class="result-list">
            <?php  $_smarty_tpl->tpl_vars['video'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['video']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['videos']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['video']->key => $_smarty_tpl->tpl_vars['video']->value){
$_smarty_tpl->tpl_vars['video']->_loop = true;
?>
                <?php if ($_smarty_tpl->tpl_vars['video']->value->getPrivacy()==true){?>
                	<li class="locked">
						<a href="#" class="video-link"><img src="/media/images/background_lock.png" /></a>
						<div class="result-image left">
							<img class="resultImage" src="<?php echo $_smarty_tpl->getConfigVariable('pandaBase');?>
<?php echo $_smarty_tpl->tpl_vars['video']->value->getPandaId();?>
<?php echo $_smarty_tpl->getConfigVariable('pandaImageExt');?>
">
						</div>
						<ul class="left">
							<li class="header"><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getLastName();?>
</li>
							<li class="position-height">Postition, Height</li>
							<li class="video-title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</li>
							<li class="month-year"><<?php ?>?php echo date('F, Y', strtotime('now')); ?<?php ?>></li>
						</ul>
						<div class="clear"></div>
				
                <?php }else{ ?>
                	
						<li>
							<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/view/<?php echo $_smarty_tpl->tpl_vars['video']->value->getId();?>
/" class="video-link"></a>
							<div class="result-image left">
								<img class="resultImage" src="<?php echo $_smarty_tpl->getConfigVariable('pandaBase');?>
<?php echo $_smarty_tpl->tpl_vars['video']->value->getPandaId();?>
<?php echo $_smarty_tpl->getConfigVariable('pandaImageExt');?>
">
							</div>
							<ul class="left">
								<li class="header"><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getLastName();?>
</li>
								<li class="position-height">Postition, Height</li>
								<li class="video-title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</li>
								<li class="month-year"><<?php ?>?php echo date('F, Y', strtotime('now')); ?<?php ?>></li>
							</ul>
							<div class="clear"></div>
						</li>
					
                <?php }?>
            <?php } ?>
            </ul>
        <?php }else{ ?>
            <h2>Sorry, no results were found.</h2>
        <?php }?>
		
		<?php if ($_smarty_tpl->tpl_vars['videoCount']->value>0){?>
	        <?php echo $_smarty_tpl->getSubTemplate ('common/pagination.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	    <?php }?>
		
	</div>
	<div id="content-right-column" class="right">
	    <?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/search.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	</div>
</div><?php }} ?>