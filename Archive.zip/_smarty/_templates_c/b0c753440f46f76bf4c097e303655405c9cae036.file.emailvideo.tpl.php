<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 15:23:10
         compiled from "_smarty/_templates/videos/emailvideo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1812656965056352e2e91f2-70331420%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b0c753440f46f76bf4c097e303655405c9cae036' => 
    array (
      0 => '_smarty/_templates/videos/emailvideo.tpl',
      1 => 1347496741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1812656965056352e2e91f2-70331420',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'message' => 0,
    'video' => 0,
    'hash' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5056352e4217a5_72288807',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5056352e4217a5_72288807')) {function content_5056352e4217a5_72288807($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/private/etc/libraries/libs/plugins/modifier.date_format.php';
?><div id="content-left-column">
    <div id="leftCol">
        <h2 id="title">Email Video</h2>
        <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

        <div id="single">
            <img src="/" class="resultImage" />
            <div class="info">
                <h2><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getFirstName();?>
 <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getLastName();?>
</h2>
                <p class="position"><?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getPosition();?>
, <?php echo $_smarty_tpl->tpl_vars['video']->value->getPlayer()->getConvertedHeight();?>
</p>
                <p class="title"><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</p>
                <p class="date"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value->getUploadDate(),'%B %d, %Y %I:%M %p');?>
</p>
            </div>
        </div>
        <form id="emailFriend" action="" method="post">
            <input type="hidden" name="hash" value="<?php echo $_smarty_tpl->tpl_vars['hash']->value;?>
" />
            <label for="from">From</label>
            <div class="inputField">
                <div class="left"></div>
                <div class="middle">
                    <input type="text" class="standard" id="from" name="from" value="Full Name" />
                </div>
                <div class="right"></div>
            </div>
            <label for="from">To</label>
            <div class="inputField last copy">
                <div class="left"></div>
                <div class="middle">
                    <input type="text" class="standard" id="email" name="email[]" value="Email Address" />
                </div>
                <div class="right"></div>
            </div>
            <div class="addAnother">
                <p>
                    <span class="plusCircle"></span>
                    <span class="addText">Add another email address</span>
                </p>
            </div>
            <div class="bigButton black">
                <div class="topLeft whiteBg"></div>
                <div class="topRight whiteBg"></div>
                <div class="bottomLeft whiteBg"></div>
                <div class="bottomRight whiteBg"></div>
                <div class="middle">
                    <input type="submit" value="Share" id="sendSearch" class="large black" />
                </div>
            </div>
        </form>
    </div>
    <div id="rightCol">
        <div id="copy">
            <p>Copy the link to share:</p>
            <div class="inputFieldSmall">
                <div class="left"></div>
                <div class="middle">
                    <input type="text" class="standard" id="from" name="from" value="Full Name" />
                </div>
                <div class="right"></div>
            </div>
        </div>
        <div id="share">
            <p>Other ways to share...</p>
            <div class="shareImg facebook"></div>
            <div class="shareImg myspace"></div>
            <div class="shareImg twitter"></div>
            <div class="shareImg linkedin"></div>
        </div>
    </div>
</div><?php }} ?>