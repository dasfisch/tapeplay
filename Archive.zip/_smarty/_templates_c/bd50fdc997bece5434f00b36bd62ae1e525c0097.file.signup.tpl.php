<?php /* Smarty version Smarty-3.1.10, created on 2012-09-12 20:06:44
         compiled from "_smarty/_templates/user/signup/signup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:175794566501612a8aa4558-27132069%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd50fdc997bece5434f00b36bd62ae1e525c0097' => 
    array (
      0 => '_smarty/_templates/user/signup/signup.tpl',
      1 => 1347496741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '175794566501612a8aa4558-27132069',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_501612a8c27aa7_52501074',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_501612a8c27aa7_52501074')) {function content_501612a8c27aa7_52501074($_smarty_tpl) {?><div class="join">
	<h1>Which account is right for you?</h1>
	
	<form id="accountTypeForm" name="accountTypeForm" method="POST" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/">
		<div class="player">
			<span class="fee">
				No Cost
			</span>
			<h2>Player</h2>
			<p>
				TapePlay was created for the player. We&rsquo;re here to give power back to the talented athletes that deserve to be seen by coaches and scouts, not just the well connected.
			</p>
			<p>
				It&rsquo;s simple. Upload videos and get seen by the people who matter. 
			</p>
			<ul class="bullets">
				<li>It&rsquo;s completely free</li>
				<li>Let coaches and scouts find you</li>
				<li>Upload as many videos as you want</li>
				<li>Know your video activity (Saves, Views, etc.) </li>
			</ul>
			<p class="font15 bold center">
				TapePlay is for 9th grade to pro
			</p>
			<button class="button button_orange_large left button_round" type="submit" value="Sign Up">Sign Up</button> 
		</div>
		
		<div class="coach">
			<div class="label"></div>
			<h2>The Coach</h2>
			<p>
				Inside are player videos that you can search, save, comment on with time stamps, and share instantly with your entire staff. Even when you&rsquo;re on the road. We&rsquo;re here to make finding talent quick and easy.
			</p>
			<ul class="bullets">
				<li>Access player videos and statistics</li>
				<li>Use VideoNotes to share time stamps and notes with staff</li>
				<li>Search for athletes by specific criteria</li>
				<li>Save any video with one click</li>
			</ul>
			<p>
				To join as a coach, you&rsquo;ll need a .edu email address. 
			</p>
		</div>
		
		<div class="clear"></div>
	</form>
</div><?php }} ?>