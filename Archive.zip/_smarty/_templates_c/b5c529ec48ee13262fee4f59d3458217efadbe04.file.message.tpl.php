<?php /* Smarty version Smarty-3.1.10, created on 2012-09-12 19:54:43
         compiled from "_smarty/_templates/common/message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17859235725023f7f21d62a0-11085175%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b5c529ec48ee13262fee4f59d3458217efadbe04' => 
    array (
      0 => '_smarty/_templates/common/message.tpl',
      1 => 1347496741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17859235725023f7f21d62a0-11085175',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5023f7f226fa63_43592451',
  'variables' => 
  array (
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5023f7f226fa63_43592451')) {function content_5023f7f226fa63_43592451($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['message']->value->message)&&$_smarty_tpl->tpl_vars['message']->value->message!=''){?>
    <h3 class="<?php echo $_smarty_tpl->tpl_vars['message']->value->type;?>
Message"><?php echo $_smarty_tpl->tpl_vars['message']->value->message;?>
</h3>
<?php }?><?php }} ?>