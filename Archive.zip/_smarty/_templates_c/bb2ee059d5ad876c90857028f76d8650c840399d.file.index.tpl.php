<?php /* Smarty version Smarty-3.1.10, created on 2012-09-30 20:55:43
         compiled from "_smarty/_templates/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4030605315032c7bd40ca91-63310000%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bb2ee059d5ad876c90857028f76d8650c840399d' => 
    array (
      0 => '_smarty/_templates/index/index.tpl',
      1 => 1349056539,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4030605315032c7bd40ca91-63310000',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5032c7bd443150_33122316',
  'variables' => 
  array (
    'sports' => 0,
    'single' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5032c7bd443150_33122316')) {function content_5032c7bd443150_33122316($_smarty_tpl) {?><div id="container">
	<div id="content">
		<div id="content-wrapper">
			<div id="splash_header">
				<div class="left">
					<img src="media/images/logo_large_286x157.jpg" alt="TapePlay Beta"/>
				</div>
				<div class="left">
					<h1>(beta)</h1>
					<h2>Video makes the world go round.</h2>
					<h3>The world&rsquo;s evolved. So has recruiting.</h3>
				</div>
			</div>
			
			<div class="clear"></div>
			
			<div id="splash_content">
				<label>PICK SPORT:</label>
				<form action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
" method="post">
					<fieldset class="left">
						<select class="select-4" name="chosenSport">
							<?php  $_smarty_tpl->tpl_vars['single'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['single']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sports']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['single']->key => $_smarty_tpl->tpl_vars['single']->value){
$_smarty_tpl->tpl_vars['single']->_loop = true;
?>
								<option value="<?php echo $_smarty_tpl->tpl_vars['single']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['single']->value->getSportName();?>
</option>
	                        <?php } ?>
						</select>
					</fieldset>
                    <button class="button button_gray_large left button_round" type="submit" value="Continue">Continue</button>
				</form>
				<!--<a href="#" class="button_gray_large button_round left" title="continue">Continue</a>-->
				<div class="clear"></div>
				<ul class="login-menu font15">
					<li><a href="/company/privacy/"">Privacy Policy</a></li>
					<li><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/">Get Started</a></li>
					<li><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/">Log In</a></li>
				</ul>
			</div>    
<?php }} ?>