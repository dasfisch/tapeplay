<?php /* Smarty version Smarty-3.1.10, created on 2012-09-30 20:50:46
         compiled from "_smarty/_templates/user/personal/playerPersonal.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11142927535023f7f2051fa7-65235706%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '02b38403432027e357d7dc99e987b583915e71fc' => 
    array (
      0 => '_smarty/_templates/user/personal/playerPersonal.tpl',
      1 => 1349056240,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11142927535023f7f2051fa7-65235706',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5023f7f21cee69_81410283',
  'variables' => 
  array (
    'userExists' => 0,
    'birthYears' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5023f7f21cee69_81410283')) {function content_5023f7f21cee69_81410283($_smarty_tpl) {?><h1>Player Sign Up</h1>
<?php echo $_smarty_tpl->getSubTemplate ('common/message.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form id="coachForm" name="login" class="joinForm" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/personal/" method="post">
	<ul class="form-fields">
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
					<input type="text" id="firstName" name="firstName" value="First Name" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			
			<div class="error-alert">
				<ul>
					<li>Enter your first name.</li>
					<li>Do not use numbers.</li>
				</ul>
			</div>
			
		</li>
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
					<input type="text" id="lastName" name="lastName" value="Last Name" rel="Last Name" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			
			<div class="error-alert">
				<ul>
					<li>Enter your last name.</li>
					<li>Do not use numbers.</li>
				</ul>
			</div>
		</li>
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
					<input type="text" id="email" name="email" value="Email" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>

            <?php if (isset($_smarty_tpl->tpl_vars['userExists']->value)&&!empty($_smarty_tpl->tpl_vars['userExists']->value)){?>
                <div class="error-alert shown">
                    <ul>
                        <li><?php echo $_smarty_tpl->tpl_vars['userExists']->value;?>
</li>
                    </ul>
                </div>
            <?php }else{ ?>
                <div class="error-alert">
                    <ul>
                        <li>Grah!</li>
                        <li>Enter valid email address.</li>
                        <li>Example: abc@generic.com</li>
                    </ul>
                </div>
            <?php }?>
		</li>
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
                    <input type="text" class="input_password" name="password" value="Password (at least six characters)" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			
			<div class="error-alert">
				<ul>
					<li>Enter password of six characters or more.</li>
				</ul>
			</div>
			
		</li>
		<li class="input-field clear">
			<ul class="three-column_sign-up left">
				<li class="left">
					<fieldset>
						<select class="select-5" name="birthYear">
							<option class="default">Birth Year</option>
							<?php echo $_smarty_tpl->tpl_vars['birthYears']->value;?>

						</select>
					</fieldset>
				</li>
				<li class="left">
					<fieldset>
						<select class="select-6" name="gender">
							<option class="default">Sex</option>
							<option value="m">Male</option>
							<option value="f">Female</option>
						</select>
					</fieldset>
				</li>
				<li class="left">
					<div class="input_custom-text input_text80 width185 left">
						<div class="custom-input_center custom-input_partial">
							<span class="custom-input_top"></span>
							<input type="text" id="zipcode" name="zipcode" value="Zip Code" />
							<span class="custom-input_bottom"></span>
						</div>
						
						<div class="custom-input_left custom-input_partial">
							<span class="custom-input_top"></span>
							<span class="custom-input_bottom"></span>
						</div>
											
						<div class="custom-input_right custom-input_partial">
							<span class="custom-input_top"></span>
							<span class="custom-input_bottom"></span>
						</div>
						
					</div>
				</li>
			</ul>
			<div class="error-alert">
				<ul>
					<li>Enter birth year.</li>
					<li>Enter sex.</li>
					<li>Enter valid 5-digit zip code.</li>
				</ul>
			</div>
		</li>
		<li class="input-field clear">
			<fieldset class="left">
				<ul class="font15">
					<li>
						<label for="i-agree">
							<span class="checkbox"><span class="check"></span></span>
							<input type="checkbox" id="i-agree" name="agree" value="I Agree" />
							By checking this box, I certify that I am 13 years of age or older.
						</label>
					</li>
				</ul>
			</fieldset>
			<div class="error-alert">
				<ul>
					<li>We appreciate your interest; however in order to use our site you must be 13 years of age or older.</li>
				</ul>
			</div>
		</li>
		<li class="input-field clear margin-clear">
			<fieldset class="left">
				<ul class="font15">	
					<li>
						<label for="terms">
							<span class="checkbox"><span class="check"></span></span>
							<input type="checkbox" id="terms" name="terms" value="I agree" />
							I agree to the <a id="signup-toc" href="#">Terms and Conditions</a> and <a id="signup-privacy" href="#">Privacy Policy</a>.
						</label>
					</li>
				</ul>
			</fieldset>
			<div class="error-alert">
				<ul>
					<li>Please agree with our Terms of Service.</li>
				</ul>
			</div>
		</li>
		<li class="input-field clear">
			<button value="Join" type="submit" class="button_black_large left button_round">Join</button> 
			<span class="form-steps">Step 1 of 3</span>
		</li>
	</ul>
</form>
<?php }} ?>