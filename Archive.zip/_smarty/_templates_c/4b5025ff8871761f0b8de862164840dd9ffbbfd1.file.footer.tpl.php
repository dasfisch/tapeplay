<?php /* Smarty version Smarty-3.1.10, created on 2012-09-14 19:16:28
         compiled from "_smarty/_templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13100369175013446fa67fb7-98877017%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4b5025ff8871761f0b8de862164840dd9ffbbfd1' => 
    array (
      0 => '_smarty/_templates/common/footer.tpl',
      1 => 1347632613,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13100369175013446fa67fb7-98877017',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5013446fa886d6_47947870',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5013446fa886d6_47947870')) {function content_5013446fa886d6_47947870($_smarty_tpl) {?>				<div class="clear"></div>
				</div> <!-- END CONTENT WRAPPER -->
			</div> <!-- END CONTENT -->
			
			<div id="footer">
				<div id="footer-wrapper">
					
					<ul id="footer-navigation">
						<li>
							<dl>
								<dt>The Basics</dt>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/getstarted/">Getting Started</a></dd>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/guidelines/">Rules of Video</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>Business Info</dt>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/advertising/">Advertising</a></dd>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/contact/">Contact Us</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>For the Curious</dt>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/faq/">Frequently Asked Questions</a></dd>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/about/">About TapePlay</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>Cool Stuff</dt>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('blogUrl');?>
" target="_blank">Blog</a></dd>
								<dd><a href="<?php echo $_smarty_tpl->getConfigVariable('shopUrl');?>
" target="_blank">Merchandise</a></dd>
							</dl>
						</li>
					</ul>
					<div class="clear"></div>
					<div id="footer-terms">
						<ul>
							<li><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/tos/">Terms of Service</a> | <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/privacy/">Privacy Policy</a></li>
							<li>&copy; <?php echo date('Y');?>
 TapePlay, LLC. All Rights Reserved </li>
						</ul>
					</div>
					
				</div> <!-- END FOOTER WRAPPER -->
			</div> <!-- END FOOTER -->
			
		</div> <!-- END CONTAINER -->
	
	</body>
	
</html><?php }} ?>