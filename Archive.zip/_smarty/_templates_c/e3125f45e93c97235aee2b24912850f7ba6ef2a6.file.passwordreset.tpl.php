<?php /* Smarty version Smarty-3.1.10, created on 2012-09-07 18:28:33
         compiled from "_smarty/_templates/account/passwordreset.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17031792585036e65dc5e0c9-28748885%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3125f45e93c97235aee2b24912850f7ba6ef2a6' => 
    array (
      0 => '_smarty/_templates/account/passwordreset.tpl',
      1 => 1347059886,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17031792585036e65dc5e0c9-28748885',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5036e65dc852d8_37051530',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5036e65dc852d8_37051530')) {function content_5036e65dc852d8_37051530($_smarty_tpl) {?><h1>Reset Your Password</h1>
<div class="confirmation-message success">
	<ul>
		<li>We just sent you a link to reset your password.</li>
		<li>Check your email and click the link to reset your password.</li>
	</ul>
</div>
<p><?php }} ?>