<?php /* Smarty version Smarty-3.1.10, created on 2012-09-07 18:16:55
         compiled from "_smarty/_templates/account/forgotpassword.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14777802055036d4d7470623-44480100%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '53e14e61c7121b5b3e931ad5d5e3dd80e3e9eb6f' => 
    array (
      0 => '_smarty/_templates/account/forgotpassword.tpl',
      1 => 1347059814,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14777802055036d4d7470623-44480100',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5036d4d749a493_49202607',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5036d4d749a493_49202607')) {function content_5036d4d749a493_49202607($_smarty_tpl) {?><h1>Reset Your Password</h1>
    <?php echo $_smarty_tpl->getSubTemplate ('common/message.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form id="passwordReset" name="passwordReset" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
account/forgot/" method="post">
    <ul class="form-fields">
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
					<input type="text" name="email" value="Email Address"/>
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			<div class="error-alert">
				<ul>
					<li>This email address is not registered.</li>
					<li>Try another email address or <a href="#">join now</a>.</li>
				</ul>
			</div>
			
		</li>
		<li class="input-field clear">
			<button type="submit" value="Continue" class="button_black_large left button_round">Continue</button> 
		</li>
	</ul>
</form>
<?php }} ?>