<?php /* Smarty version Smarty-3.1.10, created on 2012-09-28 17:18:47
         compiled from "_smarty/_templates/common/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1137105035013446f8a6307-39795119%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2e48d42d3d165e17810f914c4728e73387b798be' => 
    array (
      0 => '_smarty/_templates/common/header.tpl',
      1 => 1348803403,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1137105035013446f8a6307-39795119',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5013446f92cf81_64695817',
  'variables' => 
  array (
    'ie' => 0,
    'title' => 0,
    'sports' => 0,
    'single' => 0,
    'sport' => 0,
    'user' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5013446f92cf81_64695817')) {function content_5013446f92cf81_64695817($_smarty_tpl) {?><!DOCTYPE HTML>
<html id="www-tapeplay-com"<?php echo $_smarty_tpl->tpl_vars['ie']->value;?>
>
<head>
	<title>Tapeplay :: <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
	<link rel="stylesheet" href="/css/jquery.css" type="text/css"/>
	<link rel="stylesheet" href="/css/global.css" type="text/css"/>
	<link rel="stylesheet" href="/css/custom-form.css" type="text/css"/>

	<script type="text/javascript" src="/js/jquery.js"></script>
	<script type="text/javascript" src="/js/jwplayer.js"></script>
	<script type="text/javascript" src="/js/jquery-ui.js"></script>
	<script type="text/javascript" src="/js/jquery-main.js"></script>
	<script type="text/javascript" src="/js/tapeplay.js"></script>
	<script type="text/javascript" src="/js/jquery.panda.min.js"></script>
	<script type="text/javascript" src="/js/jquery.validate.min.js"></script>


<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp1=ob_get_clean();?><?php if ($_tmp1=='/user/personal/'){?>

	<script type="text/javascript">
		$(document).ready(function ()
		{

			$('a#signup-toc').click(function ()
			{
				var top = $(window).height() / 2 - 125;
				var left = $(window).width() / 2 - 250;

				window.open('/company/tospop/', 'tpModal', 'width=500, height=500, top=' + top + ', left=' + left + ', resizable=no, status=no, location=no, toolbar=no, scrollbars=yes');
				return false;
			});

			$('a#signup-privacy').click(function ()
			{
				var top = $(window).height() / 2 - 125;
				var left = $(window).width() / 2 - 250;

				window.open('/company/privacypop/', 'tpModal', 'width=500, height=500, top=' + top + ', left=' + left + ', resizable=no, status=no, location=no, toolbar=no, scrollbars=yes');
				return false;
			});
		});
	</script>

<?php }?>

</head>
<body>
<div id="container">
	<div id="header">
		<div id="header-wrapper">
			<div class="left">
				<h1 id="logo"><a href="/" title="TapePlay Home Page"><img src="/media/images/logo_126x69.png"
																		  alt="TapePlay Logo" height="69"
																		  width="126"/> TapePlay</a></h1>

				<form action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
" method="post" id="sportChooser">
					<fieldset>
						<select class="select-1" id="chosenSport" name="chosenSport">
						<?php  $_smarty_tpl->tpl_vars['single'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['single']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sports']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['single']->key => $_smarty_tpl->tpl_vars['single']->value){
$_smarty_tpl->tpl_vars['single']->_loop = true;
?>
							<?php if ($_smarty_tpl->tpl_vars['single']->value->getId()==$_smarty_tpl->tpl_vars['sport']->value['id']){?>
								<option value="<?php echo $_smarty_tpl->tpl_vars['single']->value->getId();?>
" selected="selected">
									<?php echo $_smarty_tpl->tpl_vars['single']->value->getSportName();?>

								</option>
								<?php }else{ ?>
								<option value="<?php echo $_smarty_tpl->tpl_vars['single']->value->getId();?>
">
									<?php echo $_smarty_tpl->tpl_vars['single']->value->getSportName();?>

								</option>
							<?php }?>
						<?php } ?>
						</select>
					</fieldset>
				</form>
			</div>
			<div class="right">
				<ul id="navigation" class="clear">
				<?php if (isset($_smarty_tpl->tpl_vars['user']->value)&&!empty($_smarty_tpl->tpl_vars['user']->value)){?>
					<li>
						<a class="<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp2=ob_get_clean();?><?php if ($_tmp2=='/account/welcome/'){?>active<?php }?>"
						   href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
account/welcome/">My Account</a>
					</li>
					<li>
						<a class="<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp3=ob_get_clean();?><?php if ($_tmp3=='/user/logout/'){?>active<?php }?>"
						   href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/logout/">Logout</a>
					</li>
					<?php }else{ ?>
					<li>
						<a class="<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp4=ob_get_clean();?><?php if ($_tmp4=='/user/signup/'){?>active<?php }?>"
						   href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/">Join<span class="fbSmall"></span></a>
					</li>
					<li>
						<a class="<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp5=ob_get_clean();?><?php if ($_tmp5=='/user/login/'){?>active<?php }?>"
						   href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/">Login</a>
					</li>
				<?php }?>
					<li>
					<?php if (isset($_smarty_tpl->tpl_vars['user']->value)&&!empty($_smarty_tpl->tpl_vars['user']->value)&&$_smarty_tpl->tpl_vars['user']->value->getAccountType()==1){?>
						<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/upload/"
						   class="infoOpen <?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp6=ob_get_clean();?><?php if ($_tmp6=='/user/upload/'){?>active<?php }?>">Upload</a>
						<?php }else{ ?>
						<div class="infoOpen">Upload
							<div class="infoBubble">
								<div class="topLeft black"></div>
								<div class="topRight black"></div>
								<div class="directionTopMiddle"></div>
								<div class="middle">
									<p>
										<strong>Players</strong> must be logged into their accounts to upload a video.
										<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/">Log in</a>.
										<br/><br/> Don't have an account yet? <a
											href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/">Sign up</a>. <br/><br/>
										<strong>Coaches and Scouts</strong> cannot upload videos. We're sure you're very talented, but we're not interested. Sorry.
									</p>
								</div>
								<div class="bottomLeft"></div>
								<div class="bottomRight"></div>
								<div class="direction"></div>
							</div>
						</div>
					<?php }?>
					</li>
					<li><a href="<?php echo $_smarty_tpl->getConfigVariable('blogUrl');?>
" target="_blank">Blog</a></li>
					<li><a class="<?php ob_start();?><?php echo $_SERVER['REQUEST_URI'];?>
<?php $_tmp7=ob_get_clean();?><?php if ($_tmp7=='/company/help/'){?>active<?php }?>"
						   href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/help/">Help</a></li>
				</ul>
			</div>
		</div>
		<!-- END HEADER WRAPPER -->
	</div>
	<!-- END HEADER -->
	<div id="content">
		<div id="content-wrapper">
<?php }} ?>