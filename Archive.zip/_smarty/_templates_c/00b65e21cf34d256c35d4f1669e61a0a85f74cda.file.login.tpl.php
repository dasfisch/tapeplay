<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 15:17:08
         compiled from "_smarty/_templates/user/login/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1516022886501612a98a53a8-01552181%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00b65e21cf34d256c35d4f1669e61a0a85f74cda' => 
    array (
      0 => '_smarty/_templates/user/login/login.tpl',
      1 => 1347826612,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1516022886501612a98a53a8-01552181',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_501612a9a12ca9_97629880',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_501612a9a12ca9_97629880')) {function content_501612a9a12ca9_97629880($_smarty_tpl) {?><h1>Log In</h1>
<p class="error">
    <?php echo $_smarty_tpl->getSubTemplate ('common/message.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</p>
<form id="loginForm" name="login" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/" method="post">
	<ul class="form-fields">
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
					<input type="text" class="standard" id="username" name="username" value="Email Address" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			
			<div class="error-alert">
				<ul>
					<li>Enter valid email address.</li>
					<li>Example: abc@generic.com</li>
				</ul>
			</div>
		</li>
		<li class="input-field clear">
			
			<div class="input_custom-text input_text80 width600 left">
				<div class="custom-input_center custom-input_partial">
					<span class="custom-input_top"></span>
                    <input type="text" class="input_password" name="password" value="Password" />
					<span class="custom-input_bottom"></span>
				</div>
				
				<div class="custom-input_left custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
									
				<div class="custom-input_right custom-input_partial">
					<span class="custom-input_top"></span>
					<span class="custom-input_bottom"></span>
				</div>
				
			</div>
			
			<div class="error-alert">
				<ul>
					<li>Incorrect password.</li>
					<li>Please reenter or <a href="#">reset</a> your password.</li>
				</ul>
			</div>
		</li>

		<li class="input-field clear">
			<button type="submit" class="button_black_large left button_round">Log In</button> 
		</li>
		<li class="input-field clear font15">
			<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
account/forgot/">Forgot your password?</a>
		</li>
	</ul>
</form><?php }} ?>