<?php /* Smarty version Smarty-3.1.10, created on 2012-09-21 12:17:37
         compiled from "_smarty/_templates/company/advertising.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20051700895031b304703b17-05321361%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '26ca328e450d0c92f18b0f380c713c4099165d03' => 
    array (
      0 => '_smarty/_templates/company/advertising.tpl',
      1 => 1348023461,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20051700895031b304703b17-05321361',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5031b3047a1ed5_13187302',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5031b3047a1ed5_13187302')) {function content_5031b3047a1ed5_13187302($_smarty_tpl) {?><div id="content-left-column" class="left">
	<h1>Advertising</h1>
	
	<p>
		Get access to one of the most highly engaged audiences around with TapePlay.
	</p>
	<h3>Demographic</h3>
	<p>
		Based on the user&rsquo;s age, sex or combination of the two.
	</p>
	
	<h3>Geographic</h3>
	<p>
		Choose by location or zip code.
	</p>
	
	<h3>Interests</h3>
	<p>
		Target ads through user viewing history which demonstrates interest in a particular category of content, such as Football or Women&rsquo;s Basketball. 
	</p>
	
	<h3>User Type</h3>
	<p>
		Select audiences by their user type, such as Player, Coach or Scout.
	</p>
	
	<h3>Keyword & Search</h3>
	<p>
		Show video advertisements based on keywords or search results.
	</p>
	
	<h3>Remarketing</h3>
	<p>
		Market to viewers who have previously visited your own site.
	</p>
	
	<p>
		We&rsquo;ve done our homework. Now let us create a customized marketing package that suits your business needs.
	</p>
	
	<p>
		<a href="mailto:advertising@tapeplay.com" title="Email TapePlay Advertising">advertising@tapeplay.com</a>
	</p>
</div>
<div id="content-right-column" class="right">
	<?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>