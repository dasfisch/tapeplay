<?php /* Smarty version Smarty-3.1.10, created on 2012-09-21 12:17:37
         compiled from "_smarty/_templates/company/getstarted.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7373269655031b3086fc0c1-42867052%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3c158e850d966d0b07bc3d50d13117aa3156d866' => 
    array (
      0 => '_smarty/_templates/company/getstarted.tpl',
      1 => 1347761633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7373269655031b3086fc0c1-42867052',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5031b30872b2d9_20483095',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5031b30872b2d9_20483095')) {function content_5031b30872b2d9_20483095($_smarty_tpl) {?><div id="content-left-column" class="left">
	<h1>Get Started</h1>
	
	<h2>Players</h2>
	
	<ol class="bullets">
		<li class="bold">
			<p>
				<span class="bold">Create an account.</span> It&rsquo;s completely free. <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/join/" title="Create an account">Click here</a>.
			</p>
		</li>
		<li class="bold">
			<p>
				<span class="bold">Upload a video.</span> To upload a video, choose a file from your computer. Give the video an accurate title and description that will help coaches and scouts discover it.
			</p>
			<p>
				If you don&rsquo;t have a video, go ask yourr coach for the game video taken at school. When you come back, log in and pick up where you left off.
			</p>
			<p class="italic">
				Upload Tip: You can upload as many videos as you&rsquo;d like.
			</p>
		</li>
		<li class="bold">
			<p>
				<span class="bold">Complete your player information.</span> The more information you give us, the better chance a coach or scout will find your video.
			</p>
		</li>
	</ol>
	
	<!-- <h2>Coaches and Scouts</h2>
	
	<ol class="bullets">
		<li class="bold">
			<p>
				<span class="bold">Create an account.</span> <a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/join/" title="Create an account">Click here</a>.
			</p>
		</li>
		<li class="bold">
			<p>
				<span class="bold">Complete school or organization information.</span> The more we know about you, the better we can serve you in the future.
			</p>
			<p>	
				<span class="bold">Pay for a subscription.</span> This helps us pay the bills and allows the site to keep providing innovative ways for you to recruit better. What are we talking about? <a href="#" title="Check out VideoNotes">Check out VideoNotes</a>.
			</p>
		</li>
		<li class="bold">
			<p>
				<span class="bold">Find talent.</span> Search for any video or player. Watch videos. Click &quot;Browse&quot; to explore the entire video library of TapePlay. 
			</p>
		</li>
	</ol> -->
	
</div>

<div id="content-right-column" class="right">
	<?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>