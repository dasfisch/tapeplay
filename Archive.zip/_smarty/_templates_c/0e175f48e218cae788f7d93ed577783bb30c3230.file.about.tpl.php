<?php /* Smarty version Smarty-3.1.10, created on 2012-09-16 16:41:49
         compiled from "_smarty/_templates/company/about.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11067393195031b311e88242-74451015%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0e175f48e218cae788f7d93ed577783bb30c3230' => 
    array (
      0 => '_smarty/_templates/company/about.tpl',
      1 => 1347496741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11067393195031b311e88242-74451015',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5031b311f1a632_26864188',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5031b311f1a632_26864188')) {function content_5031b311f1a632_26864188($_smarty_tpl) {?><div id="content-left-column" class="left">
	<h1>About Us</h1>
	
	<h2>We exist to make recruiting better.</h2>
	
	<p>
		For players, it means helping talented athletes get the important exposure they need to get to the next level. You upload a video and we put it in front of coaches and scouts across the country. 
	</p>
	<p>
		For scouts and coaches, it means putting an end to the days of sifting through dozens of DVDs with a clipboard and pencil. We&rsquo;ve brought recruiting into the digital world. Now, you can search through player videos by specific criteria, save videos, and use <span class="bold">VideoNotes</span> to instantly share notes and time stamps with your entire staff.
	</p>
	<p>
		The world&rsquo;s evolved. So has recruiting. Welcome aboard.
	</p>
	
</div>
<div id="content-right-column" class="right">
     <?php echo $_smarty_tpl->getSubTemplate ('common/sidebar/share.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div><?php }} ?>