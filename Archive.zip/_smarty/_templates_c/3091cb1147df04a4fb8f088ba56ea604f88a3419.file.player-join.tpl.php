<?php /* Smarty version Smarty-3.1.10, created on 2012-09-27 22:25:49
         compiled from "_smarty/_templates/emails/player-join.tpl" */ ?>
<?php /*%%SmartyHeaderCode:204174341550454fb4672a24-10295714%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3091cb1147df04a4fb8f088ba56ea604f88a3419' => 
    array (
      0 => '_smarty/_templates/emails/player-join.tpl',
      1 => 1348111701,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '204174341550454fb4672a24-10295714',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_50454fb480b945_39027038',
  'variables' => 
  array (
    'sport' => 0,
    'emailAddress' => 0,
    'fullYear' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50454fb480b945_39027038')) {function content_50454fb480b945_39027038($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>TapePlay</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
		.ExternalClass{
			width:100% !important;
		}
	</style>
</head>
<body marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" bgcolor="#ffffff" style="margin:0;" link="#0000ff">
<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
		<tr>
			<td align="center" style="font-size:10px; line-height:13px; text-align:center;color:#ffffff;">
				<font face="Arial, Helvetica, sans-serif" size="1" color="#ffffff" style="font-size:10px; line-height:13px;">
					Please add <a href="mailto:no-reply@tapeplay.com">no-reply@tapeplay.com</a> to your address book.
				</font>
			</td>
		</tr>
	<tr>
		<td>
			<table bgcolor="#ffffff" width="100%" cellpadding="0" cellspacing="0" border="0">
				<tr>
					<td>
						<table width="100%" bgcolor="#000000" cellpadding="0" cellspacing="0" border="0" align="center">
							<tr>
								<td width="108" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="108" height="1" alt="image" /></td>
								<td>
									<table width="100%" cellpadding="0" cellspacing="0" border="0">
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="685" height="1" alt="image" /></td></tr>
										<tr>
											<td>
												<table width="100%" cellpadding="0" cellspacing="0" border="0">
													<tr><td colspan="2" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="13" alt="image" /></td></tr>
													<tr>
														<td width="178" valign="top">
															<table align="left" cellpadding="0" cellspacing="0" border="0">
																<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="6" alt="image" /></td></tr>
																<tr>
																	<td style="font-size:0; line-height:0;"><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
"><img align="left" vspace="0" hspace="0" border="0" src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
email/common/logo.jpg" width="160" height="88" alt="TapePlay" /></a></td>
																</tr>
															</table>
														</td>
														<td valign="top">
															<table width="100%" cellpadding="0" cellspacing="0" border="0">
																<tr>
																	<td style="font-size:20px; line-height:26px;"><font face="Arial, Helvetica, sans-serif" size="5" color="#e18a07" style="font-size:20px; line-height:26px;"><strong>(beta)</strong> </font></td>
																</tr>
																<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="8" alt="image" /></td></tr>
																<tr>
																	<td style="font-size:24px; line-height:31px;"><font face="Arial, Helvetica, sans-serif" size="5" color="#ffffff" style="font-size:24px; line-height:31px;"><strong><?php echo $_smarty_tpl->tpl_vars['sport']->value;?>
</strong> </font></td>
																</tr>
															</table>
														</td>
													</tr>
													<tr><td colspan="2" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="24" alt="image" /></td></tr>
												</table>
											</td>
										</tr>
										<tr>
											<td>
												<table width="100%" cellpadding="0" cellspacing="0" border="0">
													<tr>
														<td style="font-size:43px; line-height:55px;"><font face="Arial, Helvetica, sans-serif" size="7" color="#ffffff" style="font-size:43px; line-height:55px;"><strong>Welcome Aboard</strong> </font></td>
													</tr>
													<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="1" alt="image" /></td></tr>
													<tr>
														<td valign="top" style="font-size:21px; line-height:28px;">
															<font face="Arial, Helvetica, sans-serif" size="5" color="#666666" style="font-size:21px; line-height:28px;">Let's get you to the next level. To get in front of coaches and scouts across the country, simply upload video of your best game tape.</font>
														</td>
													</tr>
													<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="24" alt="image" /></td></tr>
													<tr><td style="font-size:0; line-height:0;"><a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/"><img align="left" vspace="0" hspace="0" border="0" src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/btn-email-login.gif" width="184" height="81" alt="Log In" /></a></td></tr>
												</table>
											</td>
										</tr>
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="33" alt="image" /></td></tr>
									</table>
								</td>
								<td width="108" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="108" height="1" alt="image" /></td>
							</tr>
						</table>
						<table width="100%" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" align="center">
							<tr>
								<td width="108" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="108" height="1" alt="image" /></td>
								<td>
									<table width="100%" cellpadding="0" cellspacing="0" border="0">
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="24" alt="image" /></td></tr>
										<tr>
											<td>
												<table width="100%" cellpadding="0" cellspacing="0" border="0">
													<tr>
														<td width="80" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="80" height="1" alt="image" /></td>
														<td align="center" style="font-size:16px; line-height:24px; text-align:center;"><font face="Arial, Helvetica, sans-serif" size="3" color="#666666" style="font-size:16px; line-height:24px;">Get insider tips on how to get noticed by coaches and scouts at our blog. You’ll find out more about the entire recruiting process, including what makes a video truly stand out, recruiting events and much more. </font></td>
														<td width="80" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="80" height="1" alt="image" /></td>
													</tr>
												</table>
											</td>
										</tr>
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="24" alt="image" /></td></tr>
										<tr><td align="center" style="font-size:0; line-height:0; text-align:center;"><a href="http://blog.tapeplay.com"><img vspace="0" hspace="0" border="0" src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
email/common/btn-view.gif" width="115" height="44" alt="View Blog" /></a></td></tr>
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="45" alt="image" /></td></tr>
										<tr>
											<td>
												<table width="100%" cellpadding="0" cellspacing="0" border="0">
													<tr>
														<td align="center" style="font-size:14px; line-height:18px; text-align:center;">
															<font face="Arial, Helvetica, sans-serif" size="2" color="#666666" style="font-size:14px; line-height:18px;">
																<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/signup/" style="color:#e18a07; text-decoration:none;"><font color="#e18a07">Join</font></a>&nbsp; &nbsp; | &nbsp; &nbsp;
																<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/login/" style="color:#e18a07; text-decoration:none;"><font color="#e18a07">Log In </font></a>&nbsp; &nbsp; | &nbsp; &nbsp;
																<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
videos/browse/" style="color:#e18a07; text-decoration:none;"><font color="#e18a07">Browse </font></a>&nbsp; &nbsp; | &nbsp; &nbsp;
																<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/advertising/" style="color:#e18a07; text-decoration:none;"><font color="#e18a07">Advertising </font></a>&nbsp; &nbsp; | &nbsp; &nbsp;
																<a href="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
company/contact/" style="color:#e18a07; text-decoration:none;"><font color="#e18a07">Contact </font></a>
															</font>
														</td>
													</tr>
												</table>
											</td>
										</tr>
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="11" alt="image" /></td></tr>
										<tr>
											<td align="center" style="font-size:10px; line-height:13px; text-align:center;">
												<font face="Arial, Helvetica, sans-serif" size="1" color="#000000" style="font-size:10px; line-height:13px;">
													This email was sent by TapePlay, P.O. Box 10587, Chicago, IL 60610
													<br/>
													<br/>This email was sent to the address <a href="mailto:<?php echo $_smarty_tpl->tpl_vars['emailAddress']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['emailAddress']->value;?>
</a>. If you no longer wish to receive these emails, it's cool - you can <a href="<?php echo $_smarty_tpl->getConfigVariable('unsubscribeUrl');?>
">unsubscribe</a>. But don't think we won't miss you.
													<br/>&copy;&nbsp;<?php echo $_smarty_tpl->tpl_vars['fullYear']->value;?>
 All Rights Reserved.
												</font>
											</td>
										</tr>
										<tr><td style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="1" height="70" alt="image" /></td></tr>
									</table>
								</td>
								<td width="108" style="font-size:0; line-height:0;"><img src="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
media/images/none.gif" width="108" height="1" alt="image" /></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html><?php }} ?>