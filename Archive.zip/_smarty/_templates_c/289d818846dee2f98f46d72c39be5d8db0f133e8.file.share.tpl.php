<?php /* Smarty version Smarty-3.1.10, created on 2012-09-21 12:17:37
         compiled from "_smarty/_templates/common/sidebar/share.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15765916055031b3047a8af0-97244118%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '289d818846dee2f98f46d72c39be5d8db0f133e8' => 
    array (
      0 => '_smarty/_templates/common/sidebar/share.tpl',
      1 => 1348111701,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15765916055031b3047a8af0-97244118',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5031b3047d0fb7_39595924',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5031b3047d0fb7_39595924')) {function content_5031b3047d0fb7_39595924($_smarty_tpl) {?><h1>Get Connected</h1>
<ul id="get-connected">
	<li id="get-connected_facebook"><a href="<?php echo $_smarty_tpl->getConfigVariable('facebookUrl');?>
"  target="_blank" title="<?php echo $_smarty_tpl->getConfigVariable('facebookTitle');?>
"><?php echo $_smarty_tpl->getConfigVariable('facebookTitle');?>
</a></li>
	<li id="get-connected_google-plus"><a href="<?php echo $_smarty_tpl->getConfigVariable('googlePlusUrl');?>
"  target="_blank" title="<?php echo $_smarty_tpl->getConfigVariable('googlePlusTitle');?>
"><?php echo $_smarty_tpl->getConfigVariable('googlePlusTitle');?>
</a></li>
</ul>

<div class="clear"></div>
<div class="ad_200x200">
	<a href="<?php echo $_smarty_tpl->getConfigVariable('blogUrl');?>
" target="_blank"><img src="/media/images/ad_tapeplay-blog_200x200.jpg" height="200" width="200" /></a>
</div><?php }} ?>