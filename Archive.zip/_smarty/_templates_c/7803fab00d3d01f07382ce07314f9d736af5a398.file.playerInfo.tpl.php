<?php /* Smarty version Smarty-3.1.10, created on 2012-09-27 22:26:30
         compiled from "_smarty/_templates/user/info/playerInfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23044917650482037817029-90318230%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7803fab00d3d01f07382ce07314f9d736af5a398' => 
    array (
      0 => '_smarty/_templates/user/info/playerInfo.tpl',
      1 => 1348023854,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23044917650482037817029-90318230',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5048203798d894_50324519',
  'variables' => 
  array (
    'postSport' => 0,
    'userId' => 0,
    'hash' => 0,
    'video' => 0,
    'gradeLevels' => 0,
    'positions' => 0,
    'position' => 0,
    'startYear' => 0,
    'stats' => 0,
    'i' => 0,
    'modder' => 0,
    'stat' => 0,
    'statCount' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5048203798d894_50324519')) {function content_5048203798d894_50324519($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/private/etc/libraries/libs/plugins/modifier.date_format.php';
?><h1>Player Sign Up</h1>
<p>
	The more you tell us about yourself, the easier it is for coaches and scouts to find what they&rsquo;re looking for.
</p>
<form id="playerInfoForm" name="playerInfoForm" action="<?php echo $_smarty_tpl->getConfigVariable('baseUrl');?>
user/info/" method="post">
    <input type="hidden" name="sport" value="<?php echo $_smarty_tpl->tpl_vars['postSport']->value;?>
" />
    <input type="hidden" name="user_id" value="<?php echo $_smarty_tpl->tpl_vars['userId']->value;?>
" />
    <input type="hidden" name="hash" id="hash" value="<?php echo $_smarty_tpl->tpl_vars['hash']->value;?>
" />
    <div id="videoInfo">
        <p id="status">
            Video Status: <span class="success italic">Upload complete!</span>
        </p>
        <img src="<?php echo $_smarty_tpl->getConfigVariable('pandaBase');?>
<?php echo $_smarty_tpl->tpl_vars['video']->value->getPandaId();?>
<?php echo $_smarty_tpl->getConfigVariable('pandaImageExt');?>
" class="resultImage" />
        <div class="info">
            <h2><?php echo $_smarty_tpl->tpl_vars['video']->value->getTitle();?>
</h2>
            <p><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value->getUploadDate(),'%B %d, %Y');?>
</p>
            <p><?php echo $_smarty_tpl->tpl_vars['video']->value->getLength();?>
</p>
        </div>
    </div>
	<ul class="five-column">
		<li>
			<fieldset>
				<legend>Number</legend>
				<div class="input_custom-text input_text80 width100 left">
					<div class="custom-input_center custom-input_partial">
						<span class="custom-input_top"></span>
						<input type="text" name="number" value="##" size="4" />
						<span class="custom-input_bottom"></span>
					</div>
					
					<div class="custom-input_left custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
										
					<div class="custom-input_right custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
				</div>
			</fieldset>
		</li>
		<li>
			<fieldset>
				<legend>Level</legend>
				<ul class="font15">
					<li>
						<label for="high-school">
							<span class="checkbox"><span class="check"></span></span>
							<input type="checkbox" id="high-school" name="playingLevel" value="0" />
							High School
						</label>
					</li>
					<li>
						<label for="college">
							<span class="checkbox"><span class="check"></span></span>
							<input type="checkbox" id="college" name="playingLevel" value="1" />
							College
						</label>
					</li>
					<li>
						<label for="professional">
							<span class="checkbox"><span class="check"></span></span>
							<input type="checkbox" id="professional" name="playingLevel" value="2" />
							Professional
						</label>
					</li>
				</ul>
			</fieldset>
		</li>
		<li>
			<fieldset>
				<legend>Grade</legend>
				<fieldset>
					<select class="select-2" name="gradeLevel">
						<option class="default">Select</option>
						<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = (int)9;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=17) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = ((int)1) == 0 ? 1 : (int)1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
"><?php echo $_smarty_tpl->tpl_vars['gradeLevels']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
</option>
                        <?php endfor; endif; ?>
					</select>
				</fieldset>
			</fieldset>
		</li>
		<li>
			<fieldset>
				<legend>Position</legend>
                <ul class="font15">
                    <?php  $_smarty_tpl->tpl_vars['position'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['position']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['positions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['position']->key => $_smarty_tpl->tpl_vars['position']->value){
$_smarty_tpl->tpl_vars['position']->_loop = true;
?>
                        <li>
                            <label for="professional">
                                <span class="checkbox"><span class="check"></span></span>
                                <input type="checkbox" name="position[]" value="<?php echo $_smarty_tpl->tpl_vars['position']->value->getId();?>
" />
                                <?php echo $_smarty_tpl->tpl_vars['position']->value->getName();?>

                            </label>
                        </li>
                    <?php } ?>
                </ul>
			</fieldset>
		</li>
		<li>
			<fieldset>
				<legend>Height</legend>
				<fieldset>
					<select class="select-2" class="height" name="height">
						<option class="default">Select</option>
						<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = (int)48;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=96) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = ((int)1) == 0 ? 1 : (int)1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
"><?php echo floor($_smarty_tpl->getVariable('smarty')->value['section']['i']['index']/12);?>
" <?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']%12;?>
'</option>
                        <?php endfor; endif; ?>
					</select>
				</fieldset>
			</fieldset>
			<fieldset>
				<legend>Weight</legend>
				<div class="input_custom-text input_text36 left">
					<div class="custom-input_center custom-input_partial">
						<span class="custom-input_top"></span>
						<input type="text" name="weight" value="lbs" size="4" />
						<span class="custom-input_bottom"></span>
					</div>
					
					<div class="custom-input_left custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
										
					<div class="custom-input_right custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
					
				</div>
			</fieldset>
		</li>
	</ul>
	<div class="clear"></div>
	<fieldset>
		<legend>School/Team Info</legend>
		<ul>
			<li class="input-field clear">
				
				<div class="input_custom-text input_text80 width600 left">
					<div class="custom-input_center custom-input_partial">
						<span class="custom-input_top"></span>
						<input type="text" value="School Name" id="schoolSearchInput" name="schoolSearchInput" value="School Name" />
                        <input type="hidden" class="passer" name="schoolId" value="" />
						<span class="custom-input_bottom"></span>
					</div>
					
					<div class="custom-input_left custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
										
					<div class="custom-input_right custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
				</div>
			</li>
			<li class="input-field clear">
				<div class="input_custom-text input_text80 width600 left">
					<div class="custom-input_center custom-input_partial">
						<span class="custom-input_top"></span>
						<input type="text" id="lastName" name="headCoachName" value="Head Coach's Name" />
						<span class="custom-input_bottom"></span>
					</div>
					<div class="custom-input_left custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
					<div class="custom-input_right custom-input_partial">
						<span class="custom-input_top"></span>
						<span class="custom-input_bottom"></span>
					</div>
				</div>
			</li>
		</ul>
	</fieldset>
	<fieldset>
		<legend>Graduation Date (optional)</legend>
		<ul class="three-column_sign-up left">
			<li class="left">
				<fieldset>
					<select class="select-7" name="graduationMonth">
						<option class="default">Grad. Month</option>
						<option value="1">January</option>
						<option value="2">February</option>
						<option value="3">March</option>
						<option value="4">April</option>
						<option value="5">May</option>
						<option value="6">June</option>
						<option value="7">July</option>
						<option value="8">August</option>
						<option value="9">September</option>
						<option value="10">October</option>
						<option value="11">November</option>
						<option value="12">December</option>
					</select>
				</fieldset>
			</li>
			<li class="left">
				<fieldset>
					<select class="select-8" name="graduationYear">
						<option class="default">Grad. Year</option>
						<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = (int)$_smarty_tpl->tpl_vars['startYear']->value;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['startYear']->value+5) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = ((int)1) == 0 ? 1 : (int)1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                            <option value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
"><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
</option>
                        <?php endfor; endif; ?>
					</select>
				</fieldset>
			</li>
		</ul>
	</fieldset>
	<fieldset class="statistics">
		<legend>Statistics (optional)</legend>
		<?php if (isset($_smarty_tpl->tpl_vars['stats']->value)&&count($_smarty_tpl->tpl_vars['stats']->value)>0){?>
            <ul class="three-column">
                <?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable(0, null, 0);?>
                <?php  $_smarty_tpl->tpl_vars['stat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['stat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['stats']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['stat']->key => $_smarty_tpl->tpl_vars['stat']->value){
$_smarty_tpl->tpl_vars['stat']->_loop = true;
?>
                    <?php if ($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==0||$_smarty_tpl->tpl_vars['i']->value==0){?>
                        <!--<li>-->
                    <?php }?>
                    <li>
                    	
                    	<div class="input_custom-text input_text36 width40 right">
							<div class="custom-input_center custom-input_partial">
								<span class="custom-input_top"></span>
								<input type="text" id="lastName" name="stat[<?php echo $_smarty_tpl->tpl_vars['stat']->value->getId();?>
]" value="" />
								<span class="custom-input_bottom"></span>
							</div>
							
							<div class="custom-input_left custom-input_partial">
								<span class="custom-input_top"></span>
								<span class="custom-input_bottom"></span>
							</div>
												
							<div class="custom-input_right custom-input_partial">
								<span class="custom-input_top"></span>
								<span class="custom-input_bottom"></span>
							</div>
							
						</div>
						<span class="right"><?php echo $_smarty_tpl->tpl_vars['stat']->value->getStatName();?>
</span>
                   		</li>
                    <?php if (($_smarty_tpl->tpl_vars['i']->value%$_smarty_tpl->tpl_vars['modder']->value==$_smarty_tpl->tpl_vars['modder']->value-1&&$_smarty_tpl->tpl_vars['i']->value>$_smarty_tpl->tpl_vars['modder']->value)||$_smarty_tpl->tpl_vars['i']->value==($_smarty_tpl->tpl_vars['statCount']->value-1)){?>
                        <!--</li>-->
                    <?php }?>
                    <?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable($_smarty_tpl->tpl_vars['i']->value+1, null, 0);?>
                <?php } ?>
            </ul>
        <?php }?>
	</fieldset>
	<fieldset>
		<button value="Join" type="submit" class="button_black_large left button_round">Join</button> 
		<span class="form-steps">Step 3 of 3</span>
	</fieldset>
</form> 
<?php }} ?>