<?php /* Smarty version Smarty-3.1.10, created on 2012-09-12 19:54:43
         compiled from "_smarty/_templates/home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12448068385013446f7bef98-53547119%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a2e8587ae5e744c78e0029463618f090d3efabc7' => 
    array (
      0 => '_smarty/_templates/home.tpl',
      1 => 1347496741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12448068385013446f7bef98-53547119',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_5013446f8a1e60_03035341',
  'variables' => 
  array (
    '(\'file\')' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5013446f8a1e60_03035341')) {function content_5013446f8a1e60_03035341($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars[('file')]->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>