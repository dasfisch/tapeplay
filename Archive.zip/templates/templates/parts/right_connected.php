<h1>Get Connected</h1>
<ul id="get-connected">
	<li id="get-connected_facebook"><a href="#" title="TapePlay on Facebook">TapePlay on Facebook</a></li>
	<li id="get-connected_linkedin"><a href="#" title="TapePlay on LinkedIn">TapePlay on LinkedIn</a></li>
	<li id="get-connected_twitter"><a href="#" title="TapePlay on Twitter">TapePlay on Twitter</a></li>
	<li id="get-connected_google-plus"><a href="#" title="TapePlay on Google+">TapePlay on Google+</a></li>
</ul>

<div class="clear"></div>
<div class="ad_200x200">
	
</div>