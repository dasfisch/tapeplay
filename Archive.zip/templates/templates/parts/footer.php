				<div class="clear"></div>
				</div> <!-- END CONTENT WRAPPER -->
			</div> <!-- END CONTENT -->
			
			<div id="footer">
				<div id="footer-wrapper">
					
					<ul id="footer-navigation">
						<li>
							<dl>
								<dt>The Basics</dt>
								<dd><a href="/home.php?page=get-started">Getting Started</a></dd>
								<dd><a href="/home.php?page=community-guidelines">Community Guidelines</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>Business Info</dt>
								<dd><a href="/home.php?page=advertising">Advertising</a></dd>
								<dd><a href="/home.php?page=contact-us">Contact Us</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>For the Curious</dt>
								<dd><a href="/home.php?page=faq">Frequently Asked Questions</a></dd>
								<dd><a href="/home.php?page=about-us">About TapePlay</a></dd>
							</dl>
						</li>
						<li>
							<dl>
								<dt>Cool Stuff</dt>
								<dd><a href="#">Blog</a></dd>
								<dd><a href="#">Merchandise</a></dd>
							</dl>
						</li>
					</ul>
					<div class="clear"></div>
					<div id="footer-terms">
						<ul>
							<li><a href="/home.php?page=terms-of-service">Terms of Service</a> | <a href="/home.php?page=privacy-policy">Privacy Policy</a></li>
							<li>&copy; 2011 TapePlay, LLC. All Rights Reserved </li>
						</ul>
					</div>
					
				</div> <!-- END FOOTER WRAPPER -->
			</div> <!-- END FOOTER -->
			
		</div> <!-- END CONTAINER -->
	
	</body>
	
</html>