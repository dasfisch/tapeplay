<div id="main">
    <h2 id="reset">Reset Your Password</h2>
    <p class="success">
        <span class="greenCheckMark"></span>
        We just sent you a link to reset your password.</p>
    <p class="success lower">
        Check your email and click the link to reset your password.
    </p>
</div>
<div id="ad">
    ad
</div>