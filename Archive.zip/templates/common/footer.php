<div id="footer">
    <div class="col">
        <ul class="footerList">
            <li class="header">The Basics</li>
            <li><a href="">Getting Started</a></li>
            <li><a href="http://localhost:3500/about/guidelines">Community Guidelines</a></li>
        </ul>
    </div>
    <div class="col">
        <ul class="footerList">
            <li class="header">Business Info</li>
            <li><a href="">Getting Started</a></li>
            <li><a href="http://localhost:3500/about/guidelines">Community Guidelines</a></li>
        </ul>
    </div>
    <div class="col">
        <ul class="footerList">
            <li class="header">For the Curious</li>
            <li><a href="">Getting Started</a></li>
            <li><a href="http://localhost:3500/about/guidelines">Community Guidelines</a></li>
        </ul>
    </div>
    <div class="col last">
        <ul class="footerList">
            <li class="header">Cool Stuff</li>
            <li><a href="">Blog</a></li>
            <li><a href="http://localhost:3500/about/guidelines">Merchandise</a></li>
        </ul>
    </div>
    <div class="bottom">
        <p>
            <a href="">Terms of Service</a> |
            <a href="">Privacy Policy</a>
        </p>
        <p>
            &copy; 2011 TapePlay, LLC. All Rights Reserved
        </p>
    </div>
</div>