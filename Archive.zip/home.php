<?php
    //include_once('templates/common/header.php');
?>

<?php
    //include_once('templates/template/'.$_GET['page'].'.php');
?>

<?php
    //include_once('templates/common/footer.php');
?>


<?php

include_once('templates/templates/parts/header.php');

include_once('templates/templates/'.$_GET['page'].'.php');

include_once('templates/templates/parts/footer.php');

?>

<!-- </body>
</html> -->
